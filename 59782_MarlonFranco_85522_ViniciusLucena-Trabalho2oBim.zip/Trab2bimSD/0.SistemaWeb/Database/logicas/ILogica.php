<?php

interface iLogica {
    
}

?>