<div class="base-topo">
    <a href="index.php?link=1" class="logo"></a>
    <div class="base-busca">
        <form action="">
            <input type="text" placeholder="Pesquisa">
            <input type="submit" value="" class="but">
        </form>				
    </div>
</div>
		
<nav class="menu">
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="frm_cadastro.php">Fique por dentro</a></li>
        <li><a href="lst_contatos.html">Lista de Filmes</a></li>
    </ul>
</nav>		