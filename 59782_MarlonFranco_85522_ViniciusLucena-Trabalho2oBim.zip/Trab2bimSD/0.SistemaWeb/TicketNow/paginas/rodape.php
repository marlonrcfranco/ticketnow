<div class="base-rodape">
    <p>DIREITOS RESERVADOS TICKETNOW</p>
</div>